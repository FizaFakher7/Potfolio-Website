let button= document.querySelector("body a");
button.addEventListener("click",()=>{
    const span=document.querySelector("a span");
})